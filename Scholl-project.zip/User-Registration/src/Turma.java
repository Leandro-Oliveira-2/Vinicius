public class Turma {
    private String class_name;
    private int Maximum_capacity;
}
