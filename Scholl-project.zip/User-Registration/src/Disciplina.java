public class Disciplina {
    private String name;
    private Number id;
    private Number horario;

    public Disciplina(String name, Number id, Number horario) {
        this.setName(name);
        this.setId(id);
        this.sethorario(horario);
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Number getId() {
        return id;
    }

    public void setId(Number id) {
        this.id = id;
    }

    public Number gethorario() {
        return horario;
    }

    public void sethorario(Number horario) {
        this.horario = horario;
    }
}
