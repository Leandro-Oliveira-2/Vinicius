public class User {
    private String name;
    private String Mat;

    public User(String name, String mat) {
        this.setName(name);
        this.setMat(mat);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMat() {
        return Mat;
    }

    public void setMat(String mat) {
        Mat = mat;
    }
}
