import javax.swing.*;

public class Disciplina {
    private String name;
    private String horario;

    public Disciplina(String name, String horario) {
        this.setName(name);
        this.sethorario(horario);
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String gethorario() {
        return horario;
    }

    public void sethorario(String horario) {
        this.horario = horario;
    }


}
