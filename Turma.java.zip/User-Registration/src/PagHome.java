import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class PagHome {
    public static void main(String[] args) {
        boolean testa = true;
        String cod = null;
        int num = 0;
        ArrayList<Disciplina> cadeirasCadastradas = new ArrayList<Disciplina> ();
        while (testa) {
                JOptionPane.showMessageDialog(null,"Bem vindo ao sistema acadêmico de POO\n" +
                        "Vamos começar com o cadastro de disciplinas.\n" +
                        "Digite o código e o nome de uma disciplina:");


                JOptionPane.showMessageDialog(null,"A seguir você verá as disciplicas Disponiveis");
                cod = JOptionPane.showInputDialog("Código: 123 (ESTRUTURA DE DADOS I  2M23)\n" +
                        "Código: 321 (Programação Orientada a objetos 24M23)\n" +
                        "Código: 255 (INTRODUCAO A PSICOLOGIA 3T1234)\n" +
                        "Código: 152 (REDES DE COMPUTADORES 24M45)\n" +
                        "Código: 285 (Modelagem de dados \t3M23 5M45)\n"+
                        "Código:0 SAIR\n"+"Código: 5 Listar cadeiras cadastradas");
                num = Integer.parseInt(cod);

                switch (num){
                    case 123:
                        Disciplina num1 = new Disciplina("ESTRUTURA DE DADOS I", "2M23");
                        cadeirasCadastradas.add(num1);
                        break;

                    case 321:
                        Disciplina num2 = new Disciplina("Programação Orientada a objetos", "24M23");
                        cadeirasCadastradas.add(num2);
                        break;

                    case 255:
                        Disciplina num3 = new Disciplina("INTRODUCAO A PSICOLOGIA", "3T1234");
                        cadeirasCadastradas.add(num3);
                        break;

                    case 152:
                        Disciplina num4 = new Disciplina("REDES DE COMPUTADORES", "24M45");
                        cadeirasCadastradas.add(num4);
                        break;

                    case 285:
                        Disciplina num5 = new Disciplina("Modelagem de dados", "3M23 5M45");
                        cadeirasCadastradas.add(num5);
                        break;

                    case 0:
                        testa = false;
                        break;

                    case 5:
                       for(Disciplina c: cadeirasCadastradas) {
                           System.out.println(c);
                       }

                }
        }
    }

}